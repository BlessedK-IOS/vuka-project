"""
Engineered by Khanye Analytics
Pure-Python ultra-lightweight spatial dispatch processing algorithms.
Optimised to run natively without heavy system C-dependencies.
"""
import asyncio
import math
from app.schemas import YouthProfile, MicroGig, GigMatchResponse

class KhanyeSpatialMatcher:
    @staticmethod
    def calculate_haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """
        Calculates the great-circle distance between two points 
        on the Earth's surface using pure native mathematical functions.
        """
        # Convert decimal degrees to radians
        rad_lat1, rad_lon1, rad_lat2, rad_lon2 = map(math.radians, [lat1, lon1, lat2, lon2])

        # Haversine formula mechanics
        dlat = rad_lat2 - rad_lat1
        dlon = rad_lon2 - rad_lon1
        a = math.sin(dlat/2)**2 + math.cos(rad_lat1) * math.cos(rad_lat2) * math.sin(dlon/2)**2
        c = 2 * math.asin(math.sqrt(a))
        
        # Radius of Earth in kilometers
        earth_radius_km = 6371.0
        return c * earth_radius_km

    @classmethod
    async def process_radius_gigs(cls, youth: YouthProfile, active_gigs: list[MicroGig]) -> list[GigMatchResponse]:
        """
        Khanye Analytics proprietary native routing logic.
        Filters micro-gigs within a strict 2km threshold to eliminate youth transport costs.
        """
        matched_gigs = []
        
        # Simulating micro-second non-blocking task processing safely
        await asyncio.sleep(0.01) 

        for gig in active_gigs:
            # Check if the youth possesses the required skill profile
            if gig.required_skill in youth.skills:
                
                # Run the light native math calculation
                distance_km = cls.calculate_haversine_km(
                    youth.latitude, youth.longitude, 
                    gig.latitude, gig.longitude
                )
                
                # Keep it strictly within 2km to optimize income paths
                if distance_km <= 2.0:
                    matched_gigs.append(
                        GigMatchResponse(
                            gig_id=gig.gig_id,
                            title=gig.title,
                            payout_zar=gig.payout_zar,
                            distance_km=round(distance_km, 2)
                        )
                    )
                    
        # Sort by highest payout first to ensure maximum youth upliftment
        matched_gigs.sort(key=lambda x: x.payout_zar, reverse=True)
        return matched_gigs
