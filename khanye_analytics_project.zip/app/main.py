from fastapi import FastAPI, HTTPException, status
from fastapi.responses import HTMLResponse
import os
from app.schemas import YouthProfile, GigMatchResponse, MOCK_GIGS_DATABASE
from khanye_analytics.geospatial import KhanyeSpatialMatcher

app = FastAPI(
    title="Blessed Vuka Platform",
    description="Powered by Khanye Analytics - High-Impact Youth Upliftment Micro-Grid",
    version="1.0.0"
)

# This reads the HTML file safely relative to where main.py sits
@app.get("/", response_class=HTMLResponse)
async def read_index():
    try:
        current_dir = os.path.dirname(os.path.realpath(__file__))
        html_path = os.path.join(current_dir, "index.html")
        with open(html_path, "r", encoding="utf-8") as file:
            return file.read()
    except Exception as e:
        return f"<h3>Database File Error: {str(e)}</h3>"

@app.post("/api/v1/dispatch/match", response_model=list[GigMatchResponse], status_code=status.HTTP_200_OK)
async def dispatch_local_gigs(youth_profile: YouthProfile):
    try:
        matches = await KhanyeSpatialMatcher.process_radius_gigs(youth_profile, MOCK_GIGS_DATABASE)
        return matches
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@app.post("/api/v1/merchant/post", status_code=status.HTTP_201_CREATED)
async def post_merchant_gig(new_gig: dict):
    from app.schemas import MicroGig
    try:
        MOCK_GIGS_DATABASE.append(MicroGig(**new_gig))
        return {"status": "broadcast_success"}
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
