from pydantic import BaseModel, Field
from typing import List
from datetime import datetime

class YouthProfile(BaseModel):
    youth_id: int
    name: str
    skills: List[str]
    latitude: float = Field(..., ge=-34.8, le=-22.0, description="Valid South African Latitudes")
    longitude: float = Field(..., ge=16.4, le=33.0, description="Valid South African Longitudes")

class MicroGig(BaseModel):
    gig_id: str
    title: str
    required_skill: str
    payout_zar: float = Field(..., gt=0.0)
    latitude: float
    longitude: float
    created_at: datetime = Field(default_factory=datetime.utcnow)

class GigMatchResponse(BaseModel):
    gig_id: str
    title: str
    payout_zar: float
    distance_km: float

# The comprehensive multi-region township micro-gig database track
MOCK_GIGS_DATABASE = [
    # Alexandra Gigs
    MicroGig(gig_id="GIG-001", title="Spaza Stock Inventory Assistant", required_skill="Retail", latitude=-26.1044, longitude=28.0931, payout_zar=150.0),
    MicroGig(gig_id="GIG-002", title="Last-Mile Bicycle Courier", required_skill="Logistics", latitude=-26.1090, longitude=28.0945, payout_zar=85.0),
    MicroGig(gig_id="GIG-004", title="Local Document Digitisation", required_skill="Digital", latitude=-26.1050, longitude=28.0920, payout_zar=200.0),
    
    # East Rand Gigs (Centred near Katlehong / Vosloorus area coordinates)
    MicroGig(gig_id="GIG-005", title="East Rand Mall Promo Assistant", required_skill="Retail", latitude=-26.3150, longitude=28.2310, payout_zar=180.0),
    MicroGig(gig_id="GIG-006", title="Township Hardware Delivery Hand", required_skill="Logistics", latitude=-26.3162, longitude=28.2325, payout_zar=120.0)
]
